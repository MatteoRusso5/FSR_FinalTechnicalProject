clear, clc, close all;

run ("traj_genPassivity.m");
out = sim("PassivityBasedFinaleNoDisturbance.slx");


% === SETUP PLOT ===
set(0, 'DefaultAxesFontName', 'Times New Roman');
set(0, 'DefaultTextInterpreter', 'latex');
set(0, 'DefaultAxesTickLabelInterpreter', 'latex');
set(0, 'DefaultLegendInterpreter', 'latex');
set(0, 'DefaultAxesFontSize', 16);
set(0, 'DefaultLineLineWidth', 1.5);
set(0, 'DefaultFigureColor', 'w');

if ~exist('PassivityNoDisturbance', 'dir')
    mkdir('PassivityNoDisturbance');
end

%% === POSITION COMPARISON ===
figure('Name','Position Comparison','Position',[100 100 800 700]);
subplot(3,1,1);
plot(t, xd, 'r--', out.x.Time, out.x.Data, 'b');
ylabel('[m]');
legend('$x_d$', '$x$', 'Location','best'); grid on; box on;

subplot(3,1,2);
plot(t, yd, 'r--', out.y.Time, out.y.Data, 'b');
ylabel('[m]');
legend('$y_d$', '$y$', 'Location','best'); grid on; box on;

subplot(3,1,3);
plot(t, zd, 'r--', out.z.Time, out.z.Data, 'b');
ylabel('[m]'); xlabel('Time [s]');
legend('$z_d$', '$z$', 'Location','best'); grid on; box on;

sgtitle('Position Comparison','Interpreter','latex');
print(gcf, '-depsc2', fullfile('PassivityNoDisturbance','position_comparison.eps'));

%% === POSITION ERROR ===
figure('Name','Position Error','Position',[100 100 800 700]);
components = {'ep_x','ep_y','ep_z'};
labels = {'$e_x$','$e_y$','$e_z$'};
for i = 1:3
    subplot(3,1,i);
    plot(out.(components{i}).Time, out.(components{i}).Data, 'b');
    ylabel('[m]');
    legend(labels{i}, 'Interpreter','latex','Location','best');
    grid on; box on;
end
xlabel('Time [s]');
sgtitle('Position Error', 'Interpreter','latex');
print(gcf, '-depsc2', fullfile('PassivityNoDisturbance', 'position_error.eps'));

%% === ATTITUDE ERROR ===
figure('Name','Attitude Error','Position',[100 100 800 700]);
att_err = {'e_phi','e_theta','e_psi'};
att_labels = {'$\phi$', '$\theta$', '$\psi$'};
for i = 1:3
    subplot(3,1,i);
    plot(out.(att_err{i}).Time, out.(att_err{i}).Data, 'b');
    ylabel('[rad]');
    legend(['$e_', att_labels{i}(2:end-1), '$'], 'Interpreter','latex','Location','best');
    grid on; box on;
end
xlabel('Time [s]');
sgtitle('Attitude Error', 'Interpreter','latex');
print(gcf, '-depsc2', fullfile('PassivityNoDisturbance', 'attitude_error.eps'));

%% === ATTITUDE ANGLES COMPARISON ===
figure('Name','Angle Comparison','Position',[100 100 800 700]);
angle_fields = {'phi','theta','psi'};
angle_d_fields = {'phi_d','theta_d','psi_ws'};
angle_labels = {'\phi', '\theta', '\psi'};

for i = 1:3
    subplot(3,1,i);
    % desiderato
    if strcmp(angle_fields{i}, 'psi')
        t_des = psi_ws(:,1);
        val_des = psi_ws(:,2);
    else
        t_des = out.(angle_d_fields{i}).Time;
        val_des = out.(angle_d_fields{i}).Data;
    end
    plot(t_des, val_des, 'r--'); hold on;

    t_act = out.(angle_fields{i}).Time;
    val_act = out.(angle_fields{i}).Data;
    plot(t_act, val_act, 'b');

    ylabel('[rad]');
    legend(['$' angle_labels{i} '_d$'], ['$' angle_labels{i} '$'], ...
           'Interpreter','latex','Location','best');
    grid on; box on;
end
xlabel('Time [s]');
sgtitle('Angle Comparison', 'Interpreter','latex');
print(gcf, '-depsc2', fullfile('PassivityNoDisturbance', 'angle_comparison.eps'));

%% === 3D TRAJECTORY COMPARISON ===
figure('Name','3D Trajectory ','Position',[100 100 800 600]);
p_b = out.pb.Data;
p_d = out.pd.Data;

plot3(p_b(:,2), p_b(:,1), p_b(:,3), 'b', 'DisplayName', '$\mathbf{p}_B$');
hold on;
plot3(p_d(:,2), p_d(:,1), p_d(:,3), 'r--', 'DisplayName', '$\mathbf{p}_{d}$'); 


grid on; box on; axis vis3d;
xlabel('$y$ [m]', 'Interpreter','latex');
ylabel('$x$ [m]', 'Interpreter','latex');
zlabel('$z$ [m]', 'Interpreter','latex');
legend('Interpreter','latex','Location','best');
title('3D Trajectory Comparison', 'Interpreter','latex');
view(40, 25);
print(gcf, '-depsc2', fullfile('PassivityNoDisturbance', 'trajectory_point_3D.eps'));


%% === TOTAL THRUST FORCE ===
figure('Name','Total Thrust $u_T$','Position',[100 100 800 400]);
plot(out.uT.Time, out.uT.Data, 'b');
ylabel('[N]');
xlabel('Time [s]');
title('Total Thrust Force $u_T$', 'Interpreter','latex');
legend('$u_T$', 'Interpreter','latex', 'Location','best');
grid on; box on;

print(gcf, '-depsc2', fullfile('PassivityNoDisturbance', 'u_T.eps'));
